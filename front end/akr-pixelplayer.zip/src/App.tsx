import { Github, Play, Download, Asterisk, Sparkles, AudioLines, Layers, Music } from 'lucide-react';
import TechStackGuide from './components/TechStackGuide';
import { motion } from 'motion/react';

export default function App() {
  const categories = [
    { name: 'Local Playback', desc: 'Gapless, high-fidelity playback powered by Media3 ExoPlayer & FFmpeg.', icon: <Play className="w-6 h-6" />, colSpan: "md:col-span-2 lg:col-span-2" },
    { name: 'Cloud Stream', desc: 'Sync libraries seamlessly from Telegram, NetEase, Subsonic, and Jellyfin servers.', icon: <AudioLines className="w-6 h-6" />, colSpan: "col-span-1" },
    { name: 'Wear OS Sync', desc: 'Dynamic routing and standalone offline playback directly on your wrist.', icon: <Layers className="w-6 h-6" />, colSpan: "col-span-1" },
    { name: 'AI Playlists', desc: 'Natural language prompts turn into perfectly curated mixes translated in real-time.', icon: <Sparkles className="w-6 h-6" />, colSpan: "md:col-span-2 lg:col-span-2" }
  ];

  return (
    <div className="min-h-screen bg-[#f3efea] font-sans text-[#062b58] selection:bg-[#dbdc93] selection:text-[#062b58] flex flex-col relative overflow-hidden">
      {/* Organic Background Blobs */}
      <div
        className="absolute top-[-10%] left-[-15%] w-[60vw] h-[60vw] bg-[#6ca0ff] z-0 blur-[40px] opacity-70 hidden md:block animate-blob"
        style={{ borderRadius: '50% 50% 50% 50% / 40% 60% 60% 40%' }}
      ></div>
      <div
        className="absolute top-[-5%] left-[-10%] w-[80vw] h-[80vw] bg-[#6ca0ff] z-0 blur-[20px] opacity-70 md:hidden animate-blob"
        style={{ borderRadius: '50% 50% 50% 50% / 40% 60% 60% 40%' }}
      ></div>
      <div
        className="absolute bottom-[20%] right-[-15%] w-[70vw] h-[70vw] bg-[#fcbfff] z-0 blur-[60px] opacity-60 animate-blob"
        style={{ borderRadius: '40% 60% 30% 70% / 60% 30% 70% 40%', animationDelay: '2s' }}
      ></div>
      <div
        className="absolute top-[40%] left-[20%] w-[40vw] h-[40vw] bg-[#dbdc93] z-0 blur-[80px] opacity-40 animate-blob"
        style={{ borderRadius: '60% 40% 70% 30% / 50% 50% 50% 50%', animationDelay: '5s' }}
      ></div>

      {/* Navigation */}
      <motion.header 
        initial={{ opacity: 0, y: -20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.8, ease: "easeOut" }}
        className="relative z-20 flex justify-between items-center p-6 md:px-12 md:py-8 w-full max-w-[1800px] mx-auto"
      >
        <div className="text-2xl font-bold tracking-tight flex items-center gap-2 text-[#062b58]">
          <div className="w-8 h-8 bg-[#062b58] rounded-tl-xl rounded-br-xl rounded-tr-md rounded-bl-md flex items-center justify-center shadow-[0_4px_10px_rgba(6,43,88,0.2)]">
              <Play className="w-4 h-4 text-[#f3efea] ml-0.5" fill="currentColor" />
          </div>
          <span className="font-black text-2xl tracking-tighter">AKR<span className="font-normal opacity-60 ml-1 tracking-tight">Labs</span></span>
        </div>

        <nav className="hidden md:flex items-center gap-10 text-sm font-black tracking-wide uppercase">
          <a href="#about" className="hover:text-[#062b58] opacity-70 hover:opacity-100 transition-all">About</a>
          <a href="#experiments" className="hover:text-[#062b58] opacity-70 hover:opacity-100 transition-all">Experiments</a>
          <a href="#stack" className="hover:text-[#062b58] opacity-70 hover:opacity-100 transition-all">Tech Stack</a>
        </nav>

        <div className="flex items-center gap-4">
          <a href="https://github.com/ajaykumarreddy-k/AKR-PixelPlayer" target="_blank" rel="noreferrer" className="flex items-center justify-center px-5 py-2.5 rounded-full border-2 border-[#062b58]/10 hover:border-[#062b58] hover:bg-[#062b58] hover:text-[#f3efea] transition-all font-bold text-sm tracking-wide shadow-sm">
            <Github className="w-4 h-4 mr-2" /> Source
          </a>
        </div>
      </motion.header>

      {/* Hero / About Section */}
      <section id="about" className="relative z-10 pt-20 pb-24 md:pt-[12vh] md:pb-[15vh] px-6 flex flex-col items-center justify-center text-center max-w-[1400px] mx-auto">
        <motion.h4 
          initial={{ opacity: 0, scale: 0.9 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ duration: 0.5, ease: "easeOut" }}
          className="text-[12px] font-black tracking-widest uppercase mb-10 md:mb-14 text-[#062b58] bg-[#dbdc93] px-6 py-3 rounded-full shadow-[inset_0_2px_4px_rgba(255,255,255,0.8),0_4px_8px_rgba(6,43,88,0.1)]"
        >
          About AKR PixelPlayer
        </motion.h4>
        
        <motion.h1 
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, delay: 0.2, ease: "easeOut" }}
          className="text-[2.8rem] md:text-[4.5rem] lg:text-[6rem] xl:text-[7rem] font-black tracking-tighter leading-[0.95] text-[#062b58] max-w-[1200px]"
        >
          Discover our latest experiments and help shape the future of <br className="hidden md:block"/> 
          <span className="text-3d inline-block transform -rotate-1 origin-bottom-left text-[#f3efea]" style={{ WebkitTextStroke: '2px #062b58' }}>audio technology.</span> 
          Get early access to high-res playback, remote Wear OS syncing, and help turn these technologies <span className="text-3d inline-block transform md:translate-y-2 text-[#dbdc93]" style={{ WebkitTextStroke: '2px #062b58' }}>into products</span> you use <span className="font-black underline decoration-[#dbdc93] decoration-8 underline-offset-4 decoration-skip-ink-none">every day.</span>
        </motion.h1>
      </section>

      {/* Marquee Divider */}
      <div className="relative z-10 w-full overflow-hidden bg-[#062b58] py-4 md:py-6 transform -rotate-1 shadow-[0_10px_30px_rgba(6,43,88,0.2)] border-y border-white/20">
        <div className="flex whitespace-nowrap animate-marquee">
           {/* First Set */}
           <div className="flex items-center text-[#f3efea] text-xl md:text-3xl font-black uppercase tracking-widest pl-8 shrink-0">
              <Asterisk className="w-8 h-8 text-[#dbdc93] mx-8" /> HIGH-FIDELITY PLAYBACK
              <Asterisk className="w-8 h-8 text-[#dbdc93] mx-8" /> OFFLINE FIRST
              <Asterisk className="w-8 h-8 text-[#dbdc93] mx-8" /> METADATA FETCHING
              <Asterisk className="w-8 h-8 text-[#dbdc93] mx-8" /> DYNAMIC THEMES
              <Asterisk className="w-8 h-8 text-[#dbdc93] mx-8" /> TELEGRAM SYNC
           </div>
           {/* Second Set (Duplicate for seamless loop) */}
           <div className="flex items-center text-[#f3efea] text-xl md:text-3xl font-black uppercase tracking-widest pl-8 shrink-0">
              <Asterisk className="w-8 h-8 text-[#dbdc93] mx-8" /> HIGH-FIDELITY PLAYBACK
              <Asterisk className="w-8 h-8 text-[#dbdc93] mx-8" /> OFFLINE FIRST
              <Asterisk className="w-8 h-8 text-[#dbdc93] mx-8" /> METADATA FETCHING
              <Asterisk className="w-8 h-8 text-[#dbdc93] mx-8" /> DYNAMIC THEMES
              <Asterisk className="w-8 h-8 text-[#dbdc93] mx-8" /> TELEGRAM SYNC
           </div>
        </div>
      </div>

      {/* Features / Experiments (Bento Grid) */}
      <section id="experiments" className="relative z-20 w-full bg-white/40 backdrop-blur-3xl border-y border-white/50 py-24 md:py-32 xl:py-40">
         <div className="max-w-[1600px] mx-auto px-6 md:px-12 flex flex-col xl:flex-row gap-16 xl:gap-24">
            
            <div className="flex-1 flex flex-col justify-center">
                <motion.h2 
                   initial={{ opacity: 0, x: -30 }}
                   whileInView={{ opacity: 1, x: 0 }}
                   viewport={{ once: true, margin: "-100px" }}
                   transition={{ duration: 0.8 }}
                   className="text-5xl md:text-7xl font-black tracking-tighter mb-8 text-[#062b58] text-3d-heavy"
                >
                   Life beyond the Lab
                </motion.h2>
                <motion.p 
                   initial={{ opacity: 0 }}
                   whileInView={{ opacity: 1 }}
                   viewport={{ once: true, margin: "-100px" }}
                   transition={{ duration: 0.8, delay: 0.2 }}
                   className="text-xl md:text-3xl font-bold opacity-80 leading-relaxed mb-16 max-w-2xl text-[#062b58] tracking-tight"
                >
                   At AKR Labs, every experiment begins with a bold idea: How can a music player be more intelligent? Our team brings these ideas to life, uniting local bit-perfect playback with global streaming capabilities.
                </motion.p>

                {/* Bento Grid */}
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 md:gap-8">
                   {categories.map((cat, i) => (
                      <motion.div 
                         initial={{ opacity: 0, y: 30 }}
                         whileInView={{ opacity: 1, y: 0 }}
                         viewport={{ once: true, margin: "-50px" }}
                         transition={{ duration: 0.6, delay: i * 0.1 }}
                         key={i} 
                         className={`card-3d flex flex-col gap-6 group px-8 md:px-10 py-10 md:py-12 transition-transform duration-500 hover:-translate-y-3 cursor-default bg-white/60 hover:bg-white/90 ${cat.colSpan}`}
                      >
                         <div className="flex justify-between items-start w-full">
                            <div className="w-16 h-16 rounded-2xl bg-[#dbdc93] flex items-center justify-center text-[#062b58] font-black shadow-[inset_0_-4px_8px_rgba(0,0,0,0.1),inset_0_4px_8px_rgba(255,255,255,0.8),0_8px_16px_rgba(6,43,88,0.15)] transform group-hover:rotate-12 group-hover:scale-110 transition-all duration-300">
                               {cat.icon}
                            </div>
                            <span className="text-4xl font-black opacity-[0.05] text-[#062b58] select-none group-hover:opacity-10 transition-opacity">0{i+1}</span>
                         </div>
                         <div className="mt-auto">
                           <h3 className="text-3xl font-black tracking-tight text-[#062b58] mb-4">{cat.name}</h3>
                           <p className="opacity-80 text-lg font-medium leading-relaxed text-[#062b58]">{cat.desc}</p>
                         </div>
                      </motion.div>
                   ))}
                </div>
            </div>

            <div className="flex-1 flex flex-col justify-end items-center xl:items-end w-full mt-16 xl:mt-0 xl:pb-12 shrink-0 lg:max-w-md xl:max-w-xl">
               <motion.a
                 initial={{ opacity: 0, scale: 0.9 }}
                 whileInView={{ opacity: 1, scale: 1 }}
                 viewport={{ once: true }}
                 transition={{ duration: 0.5, delay: 0.4 }}
                 href="https://github.com/ajaykumarreddy-k/AKR-Music-Mix/releases/latest"
                 target="_blank"
                 rel="noreferrer"
                 className="btn-3d mb-16 xl:mb-24 pointer-events-auto inline-flex items-center justify-center gap-4 bg-[#062b58] text-[#f3efea] px-12 py-6 rounded-[2rem] font-black text-xl flex-shrink-0"
               >
                 <Download className="w-6 h-6" strokeWidth={3} /> Download APK
               </motion.a>

               <h1 className="text-[15vw] xl:text-[8vw] leading-[0.75] font-black tracking-tighter text-[#062b58] select-none flex flex-col items-center xl:items-end uppercase text-3d-heavy">
                 <span className="tracking-tighter">
                   AKR-Pixel
                 </span>
                 <span className="flex items-start">
                   Player <span className="text-[7vw] xl:text-[3vw] leading-none text-[#dbdc93] mt-[1vw] xl:mt-[0.5vw] ml-[2vw] font-black" style={{ textShadow: '3px 4px 0px rgba(6,43,88,1)' }}>Gooo</span>
                 </span>
               </h1>
            </div>
         </div>
      </section>

      {/* Tech Stack */}
      <section id="stack" className="relative z-10 w-full py-24 md:py-40 bg-transparent px-6 md:px-12">
         <div className="max-w-[1600px] mx-auto">
           <motion.div 
             initial={{ opacity: 0, y: 30 }}
             whileInView={{ opacity: 1, y: 0 }}
             viewport={{ once: true }}
             transition={{ duration: 0.7 }}
             className="text-center mb-20 md:mb-28"
           >
             <h2 className="text-5xl md:text-7xl lg:text-[6rem] font-black tracking-tighter text-[#062b58] mb-6 text-3d-heavy leading-[1.1]">Technical Foundation</h2>
             <p className="text-2xl md:text-3xl font-bold opacity-70 max-w-3xl mx-auto tracking-tight">Under the hood of our experiments.</p>
           </motion.div>
           <TechStackGuide />
         </div>
      </section>

      {/* Footer */}
      <footer className="w-full bg-[#062b58] text-[#f3efea] py-24 text-center text-sm font-bold tracking-widest uppercase flex flex-col items-center gap-10 relative z-20 border-t-8 border-[#dbdc93]">
         <div className="w-16 h-16 bg-[#dbdc93] rounded-2xl flex items-center justify-center text-[#062b58] transform rotate-12 shadow-[0_10px_20px_rgba(0,0,0,0.3)]">
             <Music className="w-8 h-8" strokeWidth={3} />
         </div>
         <p className="text-xl">Made with ❤️ by <a href="https://github.com/ajaykumarreddy-k" className="text-[#dbdc93] hover:text-white transition-colors underline decoration-2 underline-offset-8">ajaykumarreddy-k</a></p>
         <div className="text-[#f3efea]/40 font-bold text-xs mt-4 tracking-[0.3em]">AKR PIXELPLAYER © 2026</div>
      </footer>
    </div>
  );
}
