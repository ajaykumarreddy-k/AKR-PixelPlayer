import { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';

const techFeatures = [
  {
    id: 'engine',
    label: 'Media3 ExoPlayer',
    title: 'High-Res Playback',
    description: 'At the core lies Media3 ExoPlayer coupled with FFmpeg, enabling gapless, high-fidelity local playback across all major audio formats.',
    color: '#062b58',
    textColor: '#ffffff'
  },
  {
    id: 'architecture',
    label: 'Jetpack Compose',
    title: 'Modern UI',
    description: 'Constructed entirely in Kotlin utilizing Jetpack Compose and Material You, driving a fluid, responsive, and deeply customizable visual layer.',
    color: '#0a3a75',
    textColor: '#ffffff'
  },
  {
    id: 'cloud',
    label: 'Cloud Sync',
    title: 'Extensive Integration',
    description: 'Rich API integrations seamlessly bridge local storage with Telegram, NetEase, Subsonic, and Jellyfin music servers.',
    color: '#154a8a',
    textColor: '#ffffff'
  },
  {
    id: 'ai',
    label: 'Generative AI',
    title: 'Smart Features',
    description: 'Empowered by on-device and cloud generative models for natural-language playlist creation and real-time synchronized lyrics translation.',
    color: '#215c9e',
    textColor: '#ffffff'
  },
  {
    id: 'wear',
    label: 'Wear OS',
    title: 'Wrist Companion',
    description: 'A native companion leveraging the same robust architecture for offline wrist playback, dynamic output routing, and remote control.',
    color: '#dbdc93',
    textColor: '#062b58'
  }
];

export default function TechStackGuide() {
  const [activeIndex, setActiveIndex] = useState(0);

  return (
    <div className="card-3d w-full text-[#062b58] flex flex-col md:flex-row min-h-[500px] md:h-[700px] overflow-hidden mx-auto relative z-10 p-2 md:p-4 bg-white/40 group">
      
      {/* Dynamic Left Panel */}
      <div className="flex-1 p-8 md:p-12 lg:p-20 flex flex-col relative shrink-0 z-10 h-full bg-white/80 rounded-[2rem] shadow-[inset_0_4px_10px_rgba(255,255,255,1),inset_0_-4px_10px_rgba(0,0,0,0.05),0_10px_30px_rgba(6,43,88,0.1)] border border-white/60 transition-all duration-500">
          <div className="flex items-center gap-4 mb-auto">
              {/* Dynamic Dot */}
              <div 
                className="w-5 h-5 rounded-full shadow-[inset_0_-2px_4px_rgba(0,0,0,0.2),0_4px_8px_rgba(0,0,0,0.1)]" 
                style={{ backgroundColor: techFeatures[activeIndex].color, transition: 'background-color 0.4s ease' }}
              ></div>
              <span className="font-black tracking-widest uppercase text-sm opacity-80 shadow-sm">
                Technical Foundation
              </span>
          </div>

          <div className="relative h-full flex flex-col justify-center mt-12 mb-12">
              <AnimatePresence mode="wait">
                  <motion.div
                      key={activeIndex}
                      initial={{ opacity: 0, y: 15 }}
                      animate={{ opacity: 1, y: 0 }}
                      exit={{ opacity: 0, y: -15 }}
                      transition={{ duration: 0.35, ease: 'easeOut' }}
                      className="w-full space-y-6"
                  >
                     <h3 className="text-2xl md:text-3xl font-black tracking-tight opacity-50 uppercase">
                        {techFeatures[activeIndex].title}
                     </h3>
                     <h2 className="text-[2.2rem] sm:text-5xl md:text-6xl lg:text-[4rem] font-black tracking-tighter leading-[1.05]">
                        {techFeatures[activeIndex].description}
                     </h2>
                  </motion.div>
              </AnimatePresence>
          </div>

          <div className="mt-auto flex items-center">
            <span 
              className="inline-block py-4 px-10 text-lg font-black border-4 transition-colors duration-400 rounded-full shadow-[6px_6px_0_rgba(6,43,88,0.2)] bg-white/50" 
              style={{ borderColor: '#062b58', color: '#062b58' }}
            >
                Powered by {techFeatures[activeIndex].label}
            </span>
          </div>
      </div>

      {/* Interactive Right Color Bands */}
      <div className="flex flex-row md:flex-col lg:flex-row h-32 md:h-full w-full md:w-32 lg:w-auto shrink-0 md:pl-4 z-0 gap-2 md:gap-4 mt-4 md:mt-0">
         {techFeatures.map((feature, idx) => {
           const isActive = activeIndex === idx;
           return (
             <button
               key={feature.id}
               onMouseEnter={() => setActiveIndex(idx)}
               onClick={() => setActiveIndex(idx)}
               className="relative flex flex-col items-center justify-center lg:justify-end cursor-pointer h-full transition-all duration-500 ease-out md:w-full lg:w-[7rem] rounded-[1.5rem] md:rounded-[2rem] border-2 border-white/80"
               style={{
                  flexGrow: isActive ? 1.5 : 1,
                  backgroundColor: feature.color,
                  color: feature.textColor,
                  opacity: 1,
                  flexBasis: 0,
                  boxShadow: isActive ? 'inset 0 10px 20px rgba(0,0,0,0.3), 0 0 0 4px rgba(255,255,255,0.8)' : 'inset 0 -4px 8px rgba(0,0,0,0.1), 0 8px 16px rgba(6,43,88,0.15)',
                  transform: isActive ? 'scale(0.98) translateY(2px)' : 'scale(1) translateY(0)',
               }}
             >
               {/* Desktop: Vertical Text matching inspiration */}
               <div className="hidden lg:block mb-12 whitespace-nowrap transform rotate-180" style={{ writingMode: 'vertical-rl' }}>
                 <span className={`font-black ${isActive ? 'opacity-100' : 'opacity-80'} text-xl tracking-widest uppercase transition-opacity duration-300`}>
                    {feature.label}
                 </span>
               </div>
               
               {/* Mobile/Tablet: Centered Number Index */}
               <div className="lg:hidden flex items-center justify-center h-full w-full px-2">
                 <span className={`font-black ${isActive ? 'opacity-100 scale-125' : 'opacity-70'} text-3xl leading-tight transition-all duration-300`}>
                    0{idx + 1}
                 </span>
               </div>
             </button>
           )
         })}
      </div>
    </div>
  );
}
